<?php get_header(); ?>

	<!-- NAV BAR -->
	<?php include("includes/00_nav.php"); ?>

	<div id="wrapper">

		<!-- NEWS -->
		<section id="section_1">
			<?php include("includes/01_news.php"); ?>
		</section>

	</div><!-- END OF WRAPPER -->

<?php get_footer(); ?>