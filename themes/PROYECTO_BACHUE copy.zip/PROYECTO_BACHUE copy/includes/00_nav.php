<div id="top_header" class="header">
	<ul>
		<li>Contacto <span>info@proyectobachue.com</span></li>
		<li>Fundación Proyecto Bachué</li>
		<li>Español / Inglés</li>		
	</ul>
</div>

<div id="bottom_header" class="header">
	<ul>
		<!-- IMAGE -->
		<span id="main_logo">
			<img src="<?php bloginfo( 'template_url' ); ?>/img/logo.png" />
		</span>
		<!-- MENU -->
		<li><a href="#sobre-nosotros">Sobre Nosotros</a></li>
		<li><a href="#publicaciones">Publicaciones</a></li>
		<li><a href="#archivo">Archivo</a></li>
		<li><a href="#la-collecion">La colleción</a></li>		
	</ul>
</div>